const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('tnProductionDesktop', {
  version: '1.0.0',
  platform: process.platform
});
