@echo off
setlocal
cd /d "%~dp0"
title TN Production - Windows Builder

echo ==========================================
echo    TN Production - Windows Builder
 echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Install Node.js LTS and run this file again.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm is not available.
  pause
  exit /b 1
)

echo [1/4] Installing required packages...
npm install --no-audit --no-fund
if errorlevel 1 goto fail

echo.
echo [2/4] Building TN Production installer...
npm run dist:win
if errorlevel 1 goto fail

echo.
echo [3/4] Building TN Production portable EXE...
npm run dist:portable
if errorlevel 1 goto fail

echo.
echo [4/4] Build completed successfully.
echo.
echo Installer and portable EXE are in:
echo %cd%\dist
start "" explorer "%cd%\dist"
pause
exit /b 0

:fail
echo.
echo ERROR: Windows build failed.
echo Please send a screenshot of the error shown above.
pause
exit /b 1
