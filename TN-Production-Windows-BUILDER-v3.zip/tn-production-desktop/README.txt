TN Production Windows Desktop App

1. Extract this folder.
2. Double-click BUILD-TN-PRODUCTION.bat.
3. Wait for the installer and portable EXE to be created.
4. Open the dist folder.

The desktop app connects to the existing TN Production live application.
